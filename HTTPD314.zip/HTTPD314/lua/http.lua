-- Lua HTTP : usage: require'http'
if (not http) then
   http = {}
   http.print = print
end
-- Now check for http and make print() use http.print
if (http.print) then
   http.oprint = print
   print = http.print
end
return http
